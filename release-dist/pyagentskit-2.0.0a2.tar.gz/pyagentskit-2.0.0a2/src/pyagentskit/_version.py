"""Package version."""

__version__ = "2.0.0a2"
